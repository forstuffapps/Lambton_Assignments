package Assignment_03;

public class Vehicle 
{
	String make;
	String model;
	int year;
	
	public Vehicle()
	{
		
	}
	
	public Vehicle(String Data_Make, String Data_Model, int Data_Year)
	{
		make=Data_Make;
		   model=Data_Model;
		   year=Data_Year;
		
	}

}
