package Assignment_03;

public class Car extends Vehicle 
{
	int numDoors;
	int numPassengers;


public Car(String Data_make, String Data_model, int Data_year, int Data_numDoors, int Data_numPassengers){
	make=Data_make;
	   model=Data_model;
	   year=Data_year;
	numDoors=Data_numDoors;
	numPassengers=Data_numPassengers;
	}
}
