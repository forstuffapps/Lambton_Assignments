import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;



public class ClassMidterm 
{

	private Grade grade1;
	
	private Grade grade2;
	
	private Grade grade3;
	
	private int maxScore;
	
	//Finish the constructor 
	public ClassMidterm(int maxScore) 
	{
		// Initializing all the fields
		this.maxScore = maxScore;
		this.grade1 = grade1;
		this.grade2 = grade2;
		this.grade3 = grade3;
	}
	
	//complete the method so it adds the grade to an empty grade slot
	//or throws a RuntimeException if they are all full
	public void addGrade(Grade toAdd) 
	{
		// writing if conditions for checking the grades

		// writing condition to check if grade_1 is full or not
		if (grade1 == null) 
		{
			grade1 = toAdd; // if grade 1 is not full we are assigning the value to it
		} 
		else if (grade2 == null) // writing condition to check if grade_2 is full or not
		{
			grade2 = toAdd; // if grade 2 is not full we are assigning the value to it
		} 
		else if (grade3 == null) // writing condition to check if grade_3 is full or not
		{
			grade3 = toAdd;  // if grade 3 is not full we are assigning the value to it
		} 
		else // writing exception when all the grades are full. We will raise this exception with a message
		{
			throw new RuntimeException("All grades are full !!!");
		}
	}
	
	//finish the method so that it calculates the average score of the class, rounded to two decimal places
	public double classAverage() 
	{
		// creating a temp variable for sum
		double Temp_sum = 0.0;

		// creating a temp variable for count
		int Temp_count = 0;

		// declaring all the variables to temporary variables
		int g1 = grade1.get_the_Score();
		int g2 = grade2.get_the_Score();
		int g3 = grade3.get_the_Score();

		// writing a cndition to check if grade1 is full or not
		if (grade1 != null) 
		{
			Temp_sum += g1;
			Temp_count++;
		}
		// writing a cndition to check if grade2 is full or not
		if (grade2 != null) 
		{
			Temp_sum += g2;
			Temp_count++;
		}
		// writing a cndition to check if grade3 is full or not
		if (grade3 != null) 
		{
			Temp_sum += g3;
			Temp_count++;
		}
		// writing a cndition to check if Temp_count is 0 or not
		if (Temp_count == 0) 
		{
			return 0.0;
		}

		// calcualting the average by dividing the Temp_sum and Temp_Count
		double average = Temp_sum / Temp_count;
		// rounding the average to 2 decimals
		return Math.round(average * 100.0) / 100.0; 
	}
	
	//finish the method so that it returns the median grade in the midterm
	public int medianGrade() 
	{
		// assigning the grades to some temp variables to use them later
		int g1 = grade1.get_the_Score();
		int g2 = grade2.get_the_Score();
		int g3 = grade3.get_the_Score();

		// Creating an array named All_Grades with all the three grade values
		int[] All_Grades = { (int) g1, 
			(int) g2, 
			(int) g3 };

		// Sorting the Array All_Grades which put the values in the ascending order
		Arrays.sort(All_Grades);

		// As the array is in ascending order the median value of the 3 values will  be the middle most value
		return All_Grades[1];
	}	
	
	//finish the method so that it returns the highest grade in the midterm
	public int highestGrade() 
	{
		// assigning the grades to some temp variables to use them later
		int g1 = grade1.get_the_Score();
		int g2 = grade2.get_the_Score();
		int g3 = grade3.get_the_Score();

		// Creating an array named All_Grades with all the three grade values
		int[] All_Grades = { (int) g1, 
			(int) g2, 
			(int) g3 };

		// Sorting the Array All_Grades which put the values in the ascending order
		Arrays.sort(All_Grades);

		// As the array is in ascending order the highest will be the last value
		return All_Grades[2];
	}	
	
	//finish the method so that it returns the lowest grade in the midterm
	public int lowestGrade() 
	{
		// assigning the grades to some temp variables to use them later
		int g1 = grade1.get_the_Score();
		int g2 = grade2.get_the_Score();
		int g3 = grade3.get_the_Score();

		// Creating an array named All_Grades with all the three grade values
		int[] All_Grades = { (int) g1, 
			(int) g2, 
			(int) g3 };
		
		// Sorting the Array All_Grades which put the values in the ascending order
		Arrays.sort(All_Grades);

		// As the array is in ascending order the smallest will be the first value
		return All_Grades[0];
	}	
	
	//finish the method so that it returns the student Number with the highest grade in the midterm
	public String highestGradeStudentNumber() 
	{
		// assigning the grades to some temp variables to use them later
		int g1 = grade1.get_the_Score();
		int g2 = grade2.get_the_Score();
		int g3 = grade3.get_the_Score();

		// Declaring a temp max variable 
		int Temp_Max = Integer.MIN_VALUE;

		// Decalring a temp vaiable to stroe the student name
		String Temp_Student_Number = "";

		// Writing the condition to check if the grade 1 is max or not than the temp max
		if (g1 > Temp_Max) 
		{
			Temp_Max =  (int) g1;
			Temp_Student_Number = grade1.get_the_Student_Number();
		}
		// Writing the condition to check if the grade 2 is max or not than the temp max
		if (g2 > Temp_Max) 
		{
			Temp_Max = (int) g2;
			Temp_Student_Number = grade2.get_the_Student_Number();
		}
		// Writing the condition to check if the grade 3 is max or not than the temp max
		if (g3 > Temp_Max) 
		{
			Temp_Max = (int) g3;
			Temp_Student_Number = grade3.get_the_Student_Number();
		}

		// returning the student number for the max grade where we are storing it at the time of calcualting the max grade
		return Temp_Student_Number;
	}	
	
	//finish the method so that it returns the student Number with the lowest grade in the midterm
	public String lowestGradeStudentNumber() 
	{
		// assigning the grades to some temp variables to use them later
		int g1 = grade1.get_the_Score();
		int g2 = grade2.get_the_Score();
		int g3 = grade3.get_the_Score();

		// Declaring a temp max variable
		int Temp_Min = Integer.MAX_VALUE;

		// Decalring a temp vaiable to stroe the student name
		String Temp_Student_Number = "";

		// Writing the condition to check if the grade 1 is min or not than the temp min
		if (g1 < Temp_Min) 
		{
			Temp_Min =  (int) g1;
			Temp_Student_Number = grade1.get_the_Student_Number();
		}
		// Writing the condition to check if the grade 2 is min or not than the temp min
		if (g2 < Temp_Min) 
		{
			Temp_Min = (int) g2;
			Temp_Student_Number = grade2.get_the_Student_Number();
		}
		// Writing the condition to check if the grade 3 is min or not than the temp min
		if (g3 < Temp_Min) 
		{
			Temp_Min = (int) g3;
			Temp_Student_Number = grade3.get_the_Student_Number();
		}

		// returning the student number for the min grade where we are storing it at the time of calcualting the min grade
		return Temp_Student_Number;
	}	
}
