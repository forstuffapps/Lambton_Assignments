
public class Grade 
{

	private int score;
	
	private String studentNumber;
	
	//finish the constructor
	public Grade(int score, String studentNumber) 
	{
		this.score = score;
		this.studentNumber = studentNumber;	
	}
		
	//Create Setters/Getters

	// Defining the getters

	// defiing the getter to get the student number
	public String get_the_Student_Number() 
	{
		return studentNumber;
	}

	// defining it to get the score
	public int get_the_Score() 
	{
		return score;
	}
	// Defining the setters

	// Defining the setter for setting the score
	public void set_the_Score(int score) 
	{
		this.score = score;
	}

	// Defining the setter for setting the student number
	public void set_the_Student_Number(String studentNumber) 
	{
		this.studentNumber = studentNumber;
	}
	
	//Create equals method
}
