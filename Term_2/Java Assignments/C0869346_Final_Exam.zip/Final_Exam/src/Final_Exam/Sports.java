package Final_Exam;

public class Sports
{
	
	 String name;
	 int playerCount;
	 boolean isTeamSport ;
	
	public Sports()
	{
	}
	
	public Sports(String Name,int Player_Count,boolean is_TeamSport ){
		
		this.name=Name;
		this.playerCount=Player_Count;
		this.isTeamSport=is_TeamSport;
		
	}
	
}