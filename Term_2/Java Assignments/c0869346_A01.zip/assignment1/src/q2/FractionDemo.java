package q2;


public class FractionDemo {

    public static void main(String[] args) {
        Fraction Sample_Fraction_1 = new Fraction();
        Fraction Sample_Fraction_2 = new Fraction(8, 16);
        Fraction Sample_Fraction_3 = new Fraction(4, 8);
        Fraction Sample_Fraction_4 = new Fraction(-4, -2); 
        
        System.out.println("Sample_Fraction_1: " + Sample_Fraction_1.getNumerator() + "/" + Sample_Fraction_1.getDenominator()); 
        Sample_Fraction_1.setNumerator(2);
        Sample_Fraction_1.setDenominator(3);
        System.out.println("Sample_Fraction_1: " + Sample_Fraction_1.getNumerator() + "/" + Sample_Fraction_1.getDenominator()); 

        System.out.println("Sample_Fraction_1: " + Sample_Fraction_1.toString()); 

        Fraction Product_Fraction_1 = Sample_Fraction_1.multiply(Sample_Fraction_2);
        System.out.println("Sample_Fraction_1 * Sample_Fraction_2 = " + Product_Fraction_1); 

        Fraction Product_Fraction_2 = Sample_Fraction_1.add(Sample_Fraction_2);
        System.out.println("Sample_Fraction_1 + Sample_Fraction_2 = " + Product_Fraction_2); 

        System.out.println("Sample_Fraction_1 equals Sample_Fraction_2: " + Sample_Fraction_1.equals(Sample_Fraction_2)); 
        System.out.println("Sample_Fraction_2 equals Sample_Fraction_3: " + Sample_Fraction_2.equals(Sample_Fraction_3)); 

        System.out.println("Sample_Fraction_1 >= Sample_Fraction_2: " + Sample_Fraction_1.greaterThanOrEqualTo(Sample_Fraction_2)); 

        System.out.println("Sample_Fraction_1 <= Sample_Fraction_2: " + Sample_Fraction_1.lessThanOrEqualTo(Sample_Fraction_2)); 

        System.out.println("Sample_Fraction_4: " + Sample_Fraction_4); 
    }

}