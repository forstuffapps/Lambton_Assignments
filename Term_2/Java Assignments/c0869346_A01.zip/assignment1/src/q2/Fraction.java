package q2;

public class Fraction {

    private int numerator;
    private int denominator;

    // Defining the no parameter constructor 
    public Fraction() 
    {
        this.numerator = 0;
        this.denominator = 1;
    }

    // Defining the constructor with 2 parametersr numerator value and denominator value
    public Fraction(int n, int d) 
    {
        setNumerator(n);
        setDenominator(d);
        reduce();
    }

    // Defining the Accessor for Numerator
    public int getNumerator() 
    {
        return this.numerator;
    }

 // Defining the Accessor for Denominator
    public int getDenominator() 
    {
        return this.denominator;
    }

 // Defininng the Mutator for the Denominator
    public void setDenominator(int d) 
    {
    	if (d>0)
    	{
    		this.denominator = d;
    	}
    	else
    	{
    		this.denominator = 1;
    	}
    }
    
    // Defininng the Mutator for the Numerator
    public void setNumerator(int n) 
    {
    	if (n>=0)
    	{
    		this.numerator = n;
    	}
    	else
    	{
    		this.numerator = 1;
    	}
    }

    //Defining the Reduce method
    private void reduce() 
    {
    	int Temp_Numerator = this.numerator;
    	int Temp_Denominator = this.denominator;
        int Dividing_Factor = 1;
        for (int index = 1; index <= Temp_Numerator && index <= Temp_Denominator; index++) 
        {
            if (Temp_Numerator % index == 0 && Temp_Denominator % index == 0) 
            {
            	Dividing_Factor = index;
            }
        }
        setNumerator(Temp_Numerator/Dividing_Factor);
        setDenominator(Temp_Denominator/Dividing_Factor);
    }

    
    // Defining the toString method
    @Override
    public String toString() 
    {
        return numerator + "/" + denominator;
    }

    // Defining the multiply method
    public Fraction multiply(Fraction Parameter_Fraction) 
    {
        Fraction result = new Fraction(this.numerator * Parameter_Fraction.getNumerator(), this.denominator * Parameter_Fraction.getDenominator());
        result.reduce();
        return result;
    }

    // Defining the Add Method
    public Fraction add(Fraction Parameter_Fraction) 
    {
        int Final_Numerator = this.numerator * Parameter_Fraction.getDenominator() + Parameter_Fraction.getNumerator() * this.denominator;
        int Final_Denominator = this.denominator * Parameter_Fraction.getDenominator();
        Fraction result = new Fraction(Final_Numerator, Final_Denominator);
        result.reduce();
        return result;
    }

    // Defining the equals method
    
    public boolean equals(Fraction Parameter_Fraction) 
    {
        return this.numerator == Parameter_Fraction.getNumerator() && this.denominator == Parameter_Fraction.getDenominator();
        
    }

    // Defining the Greater Than or Equal to method
    public boolean greaterThanOrEqualTo(Fraction Parameter_Fraction) 
    {
        return ((double) this.numerator / this.denominator) >= ((double) Parameter_Fraction.getNumerator() / Parameter_Fraction.getDenominator());
    }

    // Defining the Less Than or Equal to method
    public boolean lessThanOrEqualTo(Fraction Parameter_Fraction) 
    {
    	
    	return ((double) this.numerator / this.denominator)  <=  ((double) Parameter_Fraction.getNumerator() / Parameter_Fraction.getDenominator());  
    }

    

    }