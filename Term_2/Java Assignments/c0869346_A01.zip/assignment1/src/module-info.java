/**
 * 
 */
/**
 * @author HP
 *
 */
module assignment1 {
}