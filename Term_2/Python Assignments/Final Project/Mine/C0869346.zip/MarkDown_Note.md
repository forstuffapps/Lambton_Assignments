# C0869346 Final Project
## Code Explaination
<br>

Using the `subplot()` method I have generated and plotted **4 graphs**

<br>

### **Line Graph**
>The Graph_1 is a Line graph. I have generated 50 numbers ranging 1-100.And plotted them on a Line graph.


### **Scatter Graph**
>The Graph_2 is a Scatter graph. Genetrated 20 points and scattered them across the graph.


### **Bar Graph**
> The Graph_3 is a Bar graph. The x-axis represents the months. and y-axis represents the stocks ranging 10000. Generated a Bar graph


### **Pie Graph**
> The Graph_4 is Pie chart. It shows the data of the teams and their population percentages in the company. ANd also it points out the team with the highest occupancy. The pie is **_highlighted_**