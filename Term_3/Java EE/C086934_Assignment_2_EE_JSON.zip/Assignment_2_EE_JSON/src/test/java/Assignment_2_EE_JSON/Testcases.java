package Assignment_2_EE_JSON;


import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.rules.ExpectedException;



public class Testcases 
{
	
	
	
	// Tests for Persons

	@Test(expected = NullPointerException.class)
    public void person_with_null_id_as_value() {
         Person person_1 = Person.builder().id(null).build();
    }
	
	
	@Test(expected = NullPointerException.class)
    public void person_with_null_id() {
         Person person_1 = Person.builder()
        		 .firstName("John")
        		 .lastName("Joggins")
        		 .age(23)
        		 .gender("male")
        		 .build();
    }
	
	
	@Test(expected = NullPointerException.class)
	public void person_with_null_name_as_value()
	{
		Person person_1 = Person.builder()
				.id("1")
				.firstName(null)
				.age(23)
       		 	.gender("male")
       		 	.build();
	
	}
	
	
	
	@Test(expected = NullPointerException.class)
    public void person_with_null_name() {
         Person person_1 = Person.builder()
        		 .id("2")
        		 .lastName("Joggins")
        		 .age(23)
        		 .gender("male")
        		 .build();
    }
	
	
	@Test
	public void person_with_blank_name()
	{
		try
		   {
			Person person_1 = Person.builder().lastName("").build();
		   }
		   catch(RuntimeException re)
		   {
		      String message = "lastName can't be empty";
		      assertEquals(message, re.getMessage());
		    }
	}
	
	
	@Test
	public void person_with_negative_age()
	{
		try
		   {
			Person person_1 = Person.builder().age(-3).build();
		   }
		   catch(RuntimeException re)
		   {
		      String message = "age can't be negative";
		      assertEquals(message, re.getMessage());
		    }
	}
	
	
	
	
	@Test
	public void person_with_valid_arguments()
	{
		Person person_1 = Person.builder()
				.id("5")
				.firstName("John")
				.lastName("Joggins")
				.age(34)
				.gender("male")
				.build();
		
		assertEquals("5", person_1.getId());
		assertEquals("John", person_1.getFirstName());
		assertEquals("Joggins", person_1.getLastName());
		assertTrue(34 == person_1.getAge());
		assertEquals("male", person_1.getGender());
	}
	
	
	
	
	// Tests for BlogPosts
	
	
	@Test(expected = NullPointerException.class)
	public void blogpost_with_null_id_as_value()
	{
		BlogPosts  blogposts_1 = BlogPosts.builder()
									.id(null)
									.authorId("2")
									.postContent("BlogPosts are good")
									.build();
		
	}
	
	
	@Test(expected = NullPointerException.class)
	public void blogpost_with_null_id()
	{
		BlogPosts  blogposts_1 = BlogPosts.builder()
									.authorId("2")
									.postContent("BlogPosts are good")
									.build();
		
	}
	
	
	
	
	@Test(expected = NullPointerException.class)
	public void blogpost_with_null_authorid_as_value()
	{
		BlogPosts  blogposts_1 = BlogPosts.builder()
									.id("3")
									.authorId(null)
									.postContent("BlogPosts are good")
									.build();
		
	}
	
	
	@Test(expected = NullPointerException.class)
	public void blogpost_with_null_authorid()
	{
		BlogPosts  blogposts_1 = BlogPosts.builder()
									.id("2")
									.postContent("BlogPosts are good")
									.build();
		
	}
	
	
	@Test
	public void blogpost_with_valid_arguments()
	{
		
		BlogPosts  blogposts_1 = BlogPosts.builder()
									.id("2")
									.authorId("4")
									.postContent("BlogPosts are good")
									.build();
		
		assertEquals("2", blogposts_1.getId());
		assertEquals("4", blogposts_1.getAuthorId());
		assertEquals("BlogPosts are good", blogposts_1.getPostContent());
		
	}
	
	
	@Test
	public void Blog_test_for_age() throws JsonParseException, JsonMappingException, IOException
	{
		ObjectMapper mapper = new ObjectMapper();
		List<Person> persons_data = mapper.readValue(new File("persons.json"), new TypeReference<List<Person>>() {});
		
		List<BlogPosts> blogposts_data = mapper.readValue(new File("blogPosts.json"), new TypeReference<List<BlogPosts>>() {});

		
		Blog blog_1 = new Blog(blogposts_data, persons_data);
		
		List<String> ans = Arrays.asList("123", "124");
		
		assertEquals(ans, blog_1.getPostsByAuthorAge(22));
	}
	
	
	@Test
    public void mapping_the_fizz_and_buzz() 
	{
        List<Integer> num_list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        List<String> ans = Arrays.asList("1", "fizz", "3", "fizz", "buzz", "fizz", "7", "fizz", "9", "fizzbuzz");
        assertEquals(ans, FizzBuzz.mapping_the_fizz_and_buzz(num_list));
    }
    
    @Test
    public void less_than_value_exists() 
    {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("key_1", 7);
        map.put("key_2", 45);
        
        assertTrue(FizzBuzz.less_than_value_exists(map, 14));
        assertFalse(FizzBuzz.less_than_value_exists(map, 3));
    }
    
    @Test
    public void n_largest_elements() 
    {
        List<Integer> num_list = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        List<Integer> ans = Arrays.asList(10, 9, 8);
        assertEquals(ans, FizzBuzz.n_largest_elements(num_list, 3));
    }
	
	
}
