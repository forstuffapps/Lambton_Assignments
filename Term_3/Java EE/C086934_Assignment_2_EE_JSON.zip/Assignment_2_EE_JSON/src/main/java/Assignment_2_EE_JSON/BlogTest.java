package Assignment_2_EE_JSON;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class BlogTest {

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException 
	{
		// TODO Auto-generated method stub
		
		ObjectMapper mapper = new ObjectMapper();
		
		List<Person> persons_data = mapper.readValue(new File("persons.json"), new TypeReference<List<Person>>() {});
		
		List<BlogPosts> blogposts_data = mapper.readValue(new File("blogPosts.json"), new TypeReference<List<BlogPosts>>() {});
		//persons_data.forEach(System.out::println);
		
		//blogposts_data.forEach(System.out::println);
		
		Blog blog_object = new Blog(blogposts_data, persons_data);
		System.out.println(blog_object.getPostsByAuthorAge(22));
		blog_object.getPostsByAuthorAge(22).forEach(System.out::println);
		
		

	}

}
