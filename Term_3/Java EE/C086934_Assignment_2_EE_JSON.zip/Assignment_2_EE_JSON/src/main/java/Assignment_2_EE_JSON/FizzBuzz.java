package Assignment_2_EE_JSON;


import java.util.*;
import java.util.stream.Collectors;
import java.util.Arrays;
import java.util.List;

public class FizzBuzz {

	
	public static List<String> mapping_the_fizz_and_buzz(List<Integer> num_list) 
	{
        return num_list.stream()
                .map(n -> n % 2 == 0 && n % 5 == 0 ? "fizzbuzz" : 
                         n % 2 == 0 ? "fizz" : 
                         n % 5 == 0 ? "buzz" : 
                         String.valueOf(n))
                .collect(Collectors.toList());
    }
    
    public static boolean less_than_value_exists(Map<String, Integer> mapped_values, Integer n) 
    {
        return mapped_values.values().stream()
                .anyMatch(i -> i < n);
    }
    
    public static List<Integer> n_largest_elements(List<Integer> num_List, int n) 
    {
        return num_List.stream()
                .sorted(Comparator.reverseOrder())
                .limit(n)
                .collect(Collectors.toList());
    }
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		

	}

}
