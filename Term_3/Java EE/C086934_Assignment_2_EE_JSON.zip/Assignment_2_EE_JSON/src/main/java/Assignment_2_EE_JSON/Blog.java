package Assignment_2_EE_JSON;


import lombok.Data;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.Builder;



@Data
public class Blog 
{
	private final  List<BlogPosts> posts;
	private final  List<Person> contributors;
	
	public List<String> getPostsByAuthorAge(Integer age)
	{
		List<String> Person_Ids = contributors.stream()
				.map(i -> i.getId())
				.collect(Collectors.toList());
		//System.out.println(Person_Ids);
		//System.out.println(contributors);
		/*
		List<String> ans = posts.stream()
				.filter(p -> Person_Ids.contains(p.getAutorId()) && p.getAge().equals(age))
				.map(i -> i.getId())
				.collect(Collectors.toList());
		
		return ans;
		*/
		
		return posts.stream()
                .filter(b -> contributors.stream()
                        .anyMatch(p -> p.getId().equals(b.getAuthorId()) && age==p.getAge()))
                .map(i -> i.getId())
                .collect(Collectors.toList());
        
	}
}
