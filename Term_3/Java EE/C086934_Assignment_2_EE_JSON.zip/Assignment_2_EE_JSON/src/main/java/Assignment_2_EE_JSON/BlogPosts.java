package Assignment_2_EE_JSON;


import lombok.Data;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.Builder;


@Data
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class BlogPosts 
{
	
	@NonNull
	private final String id;

	@NonNull
	private final String authorId; //This is equal to personId

	private final String postContent;
	
	@Builder
	@JsonCreator
	private static BlogPosts of(@JsonProperty("id") String id,
			@JsonProperty("authorId") String authorId,
			@JsonProperty("postContent") String postContent)
	{
		
		return new BlogPosts(id, authorId, postContent);
	}
	
}
