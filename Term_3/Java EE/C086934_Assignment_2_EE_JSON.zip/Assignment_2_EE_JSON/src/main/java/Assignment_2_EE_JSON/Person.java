package Assignment_2_EE_JSON;


import lombok.Data;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AccessLevel;
import lombok.Builder;

@Data
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class Person 
{
	
	@NonNull
	private final String id;

	@NonNull
	private final String firstName;

	@NonNull
	private final String lastName;

	private final Integer age;

	private final String gender;
	
	
	@Builder
	@JsonCreator
	private static Person of(@JsonProperty("id") String id,
			@JsonProperty("firstName") String firstName, 
			@JsonProperty("lastName") String lastName,
			@JsonProperty("age") Integer age, 
			@JsonProperty("gender") String gender )
	{
		if ("".equals(id))
		{
			throw new RuntimeException("id can't be empty");
		}
		
		if ("".equals(firstName))
		{
			throw new RuntimeException("firstName can't be empty");
		}
		
		if ("".equals(lastName))
		{
			throw new RuntimeException("lastName can't be empty");
		}
		
		if (age<0)
		{
			throw new RuntimeException("age can't be negative");
		}
		
		
		return new Person(id, firstName, lastName, age, gender);

	}
	
}
