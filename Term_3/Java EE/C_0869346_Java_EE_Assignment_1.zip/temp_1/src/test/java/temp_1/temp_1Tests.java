package temp_1;

import static org.junit.Assert.*;

import org.junit.Test;


public class temp_1Tests {
	
	
	@Test
    public void test_case_1()
	{
        Dog D_1 = new Dog("Dog_id_1", 34);
        Person P_1 = new Person("Person_id_1", 56, D_1);
        P_1.changeDogsName("Dog_id_changed");
        assertEquals("Dog_id_changed", D_1.getName());
    }

	
	@Test
	public void test_case_2()
	{
		Dog D_2 = new Dog("Dog_id_2", 12);
		Person P_2 = new Person("Person_id_2", 34,D_2);
		assertEquals(true, P_2.hasOldDog());
	}
	
	
	@Test
	public void test_case_3()
	{
		Dog D_3 = new Dog("Dog_id_3", 9);
		Person P_3 = new Person("Person_id_3", 65,D_3);
		assertEquals(false, P_3.hasOldDog());
	}
	
	
	@Test
	public void test_case_4()
	{
		Dog D_4 = new Dog("Dog_id_4", 10);
		Person P_4 = new Person("Person_id_4", 76,D_4);
		assertEquals(true, P_4.hasOldDog());
	}
    

}
