package temp_1;

public class Dog 
{
	String name;
	Integer age;
	
	public Dog(String name, Integer age)
	{
		this.name = name;
		this.age = age;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	
	public Integer getAge()
	{
		return this.age;
	}
	

	

	public void setName(String Name)
	{
		this.name = Name;
	}
	
	public void setAge(Integer Age)
	{
		this.age = Age;
	}

	

	
	
	
	
	
	

}
