package temp_1;
import java.util.Optional;


public class Person 
{
	String name;
	Integer age;
	Optional<Dog> dog;
	

	public Person (String name, Integer age) //should call the below constructor
	{
		this(name,age,null);
	}
	public Person (String name, Integer age, Dog dog)
	{
		this.name = name;
		this.age = age;
		this.dog = Optional.ofNullable(dog);
	}
	
	public boolean hasOldDog()
	{
       return dog.get()!=null && dog.get().getAge()>=10;
		

       
    }
	
	public void changeDogsName(String newName)
	{
		while(this.dog != null) {
	       this.dog.get().setName(newName);
	       break;
	    }
	    while(this.dog == null) 
	    {
	        throw new RuntimeException(this.name + " does not own a dog!");
	    }
	   
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String N)
	{
		name = N;
	}
	
	public Integer getAge()
	{
		return age;
	}
	
	public void setAge(Integer A)
	{
		age = A;
	}
	
	public Optional<Dog> getDog()
	{
		return dog;
	}
	
	public void setDog(Optional<Dog> D)
	{
		dog = D;
	}
	
	
	
	
	
	

}
