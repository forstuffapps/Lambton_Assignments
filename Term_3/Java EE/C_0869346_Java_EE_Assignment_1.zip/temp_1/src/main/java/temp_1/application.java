package temp_1;

public class application
{
    public static void main(String[] args) 
    {
        Person P_1 = new Person("Vishal", 24);
        try
        {
        	P_1.changeDogsName("Snoopy_Dog");
        }
        catch (RuntimeException e)
        {
            System.out.println("Unable to change dog's name: " + e.getMessage());
        }
    }
}

